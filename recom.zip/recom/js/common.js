$(function() {
    //Scroll
	var windowHeight = $(window).height();
 
	/*$(document).on('scroll', function() {
		$('.scroll').each(function() {
			var self = $(this),
			height = self.offset().top + self.height();
			if ($(document).scrollTop() + windowHeight >= height) {
				self.addClass('fromBottom')
			}
        });
    });
	$(document).on('scroll', function() {
		$('.scrollRight').each(function() {
			var self = $(this),
			height = self.offset().top + self.height();
			if ($(document).scrollTop() + windowHeight >= height) {
				self.addClass('fromRight')
			}
        });
    });*/
    $(document).on('scroll', function() {
		$('.candles').each(function() {
			var self = $(this),
			height = self.offset().top + self.height();
			if ($(document).scrollTop() + windowHeight >= height) {
				self.addClass('bars')
			}
        });
	});
    //End Scroll
	$('.popup-youtube').hover(function(){
		$('#bt_play_video').addClass('tuktuk');
	}, function(){
		$('#bt_play_video').removeClass('tuktuk');
	})

    //Slick Slider
    $('.reviews').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        dots: false,
        arrows:false,
        infinite: false
    });
    $('.left-arrow').on('click', function() {
        $('.reviews').slick('slickPrev');
    });

    $('.right-arrow').on('click', function() {
        $('.reviews').slick('slickNext');
    });
    //End Slick Slider

    //Popup
    $('.popup-youtube').magnificPopup({
		disableOn: 700,
		type: 'iframe',
		mainClass: 'mfp-fade',
		removalDelay: 160,
		preloader: false,
		fixedContentPos: false
	});
	//End Popup

	/*var options = {
		offset: 1000,
		classes: {
			clone:   'banner--clone',
			stick:   'banner--stick',
			unstick: 'banner--unstick'
		}
	};

	var header = new Headhesive('.nav-wrap', options);*/
	
	//Wow
	new WOW().init();
	//End wow
	$('.adaptive-btn').click(function(){
		$('.menu--mobile').fadeIn();
	})
	$('.adaptive-btn--dismiss').click(function(){
		$('.menu--mobile').fadeOut();
	})
});
